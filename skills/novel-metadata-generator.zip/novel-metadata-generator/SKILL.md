---
name: novel-metadata-generator
description: 为玄幻小说生成符合平台规则的元数据（书名、标签、主角名、简介、封面提示词）。基于 world\outline.md 的内容，并严格遵守 references\platform-rules.md 中的字数和内容限制，从 references\tag-options.md 中选择合适的标签。
---

# Novel Metadata Generator

该技能用于在小说创作初期或发布前，根据 `world\outline.md` 中的大纲内容，自动生成符合特定文学平台规范的元数据。

## 核心流程 (Core Workflow)

1. **读取背景**：首先读取 `world\outline.md` 以获取故事核心梗、金手指、主角设定及剧情走向。
2. **规则校验**：参考 [platform-rules.md](references/platform-rules.md) 了解字数限制、命名规范和禁忌内容。
3. **标签匹配**：从 [tag-options.md](references/tag-options.md) 中挑选最契合的主分类及各维度标签。
4. **生成内容**：
   - **书名**：生成 5-7 个符合规则（<15字）且吸睛的候选项。
   - **主角名**：确认或微调主角名（<5字）。
   - **标签组**：输出完整标签列表。包含 1 个主分类，以及 2 套副标签候选项（每套包含主题、角色、情节三个维度，每个维度最多 2 个标签）。
   - **作品简介**：撰写 50-500 字的简介，突出“黄金三章”爽点。
   - **封面提示词**：遵循 **ReAct 封面构思协议**，为每个书名生成与之匹配的 AI 绘画提示词。要求通过推理分析确保视觉元素与书名意境、主角形象、标签及简介核心设定高度一致。标注为“中文小说封面”，严禁英文。
5. **结果归档**：将生成的全量元数据汇总，并保存至项目根目录下的 `metadata\novel-metadata.md` 文件中。如果该文件已存在，则直接覆盖。

## 使用指南 (Usage Guidelines)

### 1. 数据持久化规范 (Data Persistence)
- **存储路径**：`metadata\novel-metadata.md`。
- **操作逻辑**：每次执行该技能并生成最终结果后，必须自动创建或更新该文件。
- **覆盖机制**：采用全量覆盖模式，确保文件中记录的是最新生成的元数据信息。

### 2. ReAct 封面构思协议 (ReAct Design Protocol)
在生成每个封面提示词前，必须执行以下思维链：
- **Thought (推理)**：
  - **意境分析**：分析书名传达的氛围（如“霸气”、“深邃”、“玄奥”）。
  - **角色对齐**：提取主角的关键特征（发色、瞳色、服饰、武器、神态）。
  - **元素提取**：根据标签和简介提取核心视觉符号。
  - **构图设计**：应用专业构图法（如：黄金分割、对角线构图、三分法、中心构图）。
  - **MJ 参数规划**：规划 `--ar 3:4`（对应 600x800）、`--v 6.0`、`--niji 6`（动漫风）等参数。
- **Action (生成)**：
  - 根据 Thought 的分析，填充 [Midjourney 专业级模板] 生成最终提示词。

### 3. 标签选择逻辑
- **主分类**：必须与 `world\outline.md` 的题材高度一致。
- **副标签候选项**：提供两套不同侧重点的组合，每套维度（主题、角色、情节）各限 2 个。

### 4. 简介撰写标准
- **开头**：一句话直击核心梗。
- **中段**：展示冲突与金手指带来的反差。
- **结尾**：抛出悬念或期待感。

### 5. Midjourney 专业级提示词模板 (MJ Professional Template)
为了生成 Midjourney 能够理解并产生高质量构图的提示词，必须遵循以下结构：

- **[核心主体]**：Subject + Action + Pose (e.g., A handsome cultivator standing on a flying sword, calm expression).
- **[场景与背景]**：Environment + Lighting + Atmosphere (e.g., Majestic floating mountains, sunset glow, epic scale).
- **[构图与视角]**：Composition technique + Camera angle (e.g., Rule of thirds, low angle shot, wide shot).
- **[材质与渲染]**：Material + Rendering engine (e.g., Silk texture, Unreal Engine 5 render, Octane render, 8k, highly detailed).
- **[艺术风格]**：Art style + Artist reference (e.g., Chinese ink painting fusion, cyberpunk aesthetic, digital oil painting).
- **[MJ 尾部参数]**：必须包含 `--ar 3:4 --v 6.0` 或 `--niji 6`。
- **[中文排版声明]**：在提示词开头或结尾明确要求“Chinese novel cover layout, reserve space for title [作品名称] at top and author [作者笔名] at bottom. No English text on image.”

#### 最佳实践示例 (MJ Reference Example)：
> **Midjourney Prompt**: 
> A calm young cultivator with long black hair, wearing profound cyan ancient robes, sitting in meditation, blue holographic data streams and circuit diagrams emanating from his forehead, merging with traditional spiritual energy, --ar 3:4 --v 6.0 --stylize 250 --chaos 10.
> **构图与风格**：Epic scale digital painting, cinematic lighting, fusion of oriental classicism and cyberpunk aesthetic, golden ratio composition, rule of thirds. 
> **排版要求**：Chinese novel cover, reserve space for title **[作品名称]** at top center and author **[作者笔名]** at bottom right. Ensure no English text appears on the final artwork.

## 参考资源 (Resources)
- [platform-rules.md](references/platform-rules.md)：平台限制规则（字数、字符、内容禁忌）。
- [tag-options.md](references/tag-options.md)：标准化的分类与标签库。

